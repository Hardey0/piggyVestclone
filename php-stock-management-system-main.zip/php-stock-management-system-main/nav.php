<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="navstyling.css">
</head>
<body>
    <div class="container">
        <div class="left-side">
        <nav>
        <ul>
            <li><a href="index.php">Dashboard</a></li>
            <!-- <li><a href="categories.php">Categories</a></li> -->
            <li><a href="products.php">Products</a></li>
            <!-- <li><a href="sales.php">Sales</a></li> -->
            <li><a href="salesreport.php">Sales Report</a></li>
        </ul>
    </nav>
        </div>
    </div>
</body>
</html>